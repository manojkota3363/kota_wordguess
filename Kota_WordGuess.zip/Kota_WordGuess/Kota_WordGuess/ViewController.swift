//
//  ViewController.swift
//  Kota_WordGuess
//
//  Created by student on 3/29/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsMissedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    @IBOutlet weak var guessinglabel: UILabel!
    
    @IBOutlet weak var hintLabel: UILabel!
    @IBOutlet weak var guessLetterField: UITextField!
    @IBOutlet weak var guessLetterButton: UIButton!
    @IBOutlet weak var guessCountLabel: UILabel!
    @IBOutlet weak var playAgainButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    var arraywords = [["BOOKS","Used to read"],
                        ["PEN","used to write"],["CAR","Used to travel"],["GAS","used as fuel"],["KNIFE","used for cutting"]]
    
    var guess = ""
    var imagesnames = ["book","pen","car","gas1","knife","tryy"]
    var l = ""
    var wordIterator = 0
    var guessedletcount = ""
    let maxNumOfWrongGuesses  = 10
    var guessleft = 10
    var count = 0
    var guessedwords = 0
    var wronginputs = 0
    var tryvariable=0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        l = arraywords[wordIterator][0]
        guess = arraywords[wordIterator][1]
        hintLabel.text = "HINT: " + guess;
        wordsGuessedLabel.text = "Total number of words Guessed  succesfully:0"
        wordsMissedLabel.text = "Total number of words guessed wrongly : 0"
        totalWordsLabel.text = "Total number of words in the game: \(arraywords.count)"
        wordsRemainingLabel.text = "Total number of words remaining in the game: \(arraywords.count)"
        guessCountLabel.text = "You have Made 0 guesses"
        guesslabelouput()
        guessLetterButton.isEnabled = false
        
        playAgainButton.isHidden = true
    }

   
    
    
    func updateoutputs(){
        
        wordsMissedLabel.text = "Total number of words guessed wrongly :\(wronginputs)"
        wordsGuessedLabel.text = "Total number of words Guessed  succesfully: \(guessedwords)"
        
        wordsRemainingLabel.text = "Total number of words remaining in the game:\(arraywords.count - (guessedwords + wronginputs))"
    }
   
    func guesslabelouput() {
        var ouput = ""
        guessedletcount += guessLetterField.text!
        
        for letter in l {
            if guessedletcount.contains(letter) {
                ouput = ouput + " \(letter)"
            } else {
                ouput += " _"
            }
        }
        ouput.removeFirst()
        guessinglabel.text = ouput
    }
    
    func guessmethod(){
        
        guessLetterField.resignFirstResponder()
        
        guessLetterField.text = ""
    }
    
    
    func guesslettermethod() {
        guesslabelouput()
        count += 1
        
        
        let letterguessed = guessLetterField.text!
        
        if !l.contains(letterguessed) {
            
            guessleft = guessleft - 1
            
        }
        
        let outputword = guessinglabel.text!
        
        if guessleft == 0 {
            
            playAgainButton.isHidden = false
            guessLetterField.isEnabled = false
            guessLetterButton.isEnabled = false
           // tryvariable+=1
            guessCountLabel.text = "You have used all the available guesses, Please start again” "
            wronginputs += 1
            updateoutputs()
            updateImageView()
        } else if !outputword.contains("_") {
           
            playAgainButton.isHidden = false
            guessLetterField.isEnabled = false
            guessLetterButton.isEnabled = false
            guessCountLabel.text = "You won,it took you \(count) attempts to guesses the word!"
            hintLabel.text = "HINT: A game played";

            guessedwords += 1
            updateoutputs()
            updateImageView()
        } else {
            // Update our guess count
            //let guess = ( count == 1 ? "Guess" : "Guesses")
            guessCountLabel.text = "You have Made \(count) guesses"
        }
        
        if (guessedwords + wronginputs) == arraywords.count {
            guessCountLabel.text = "Congratulations, You are done, Please start over again "
            updateImageView()
        }
    }
    
  
    
    @IBAction func guessLetterFieldChanged(_ sender: UITextField) {
        if let letterGuessed = guessLetterField.text?.last {
            guessLetterField.text = "\(letterGuessed)"
            guessLetterButton.isEnabled = true
        } else {
            
            guessLetterButton.isEnabled = false
        }
    }
    
    @IBAction func doneKeyPressed(_ sender: UITextField) {
        guesslettermethod()
        guessmethod()
        let letter = guessLetterField.text
        if letter?.isEmpty == true{
            guessLetterButton.isEnabled = false
        }
        else{
            guessLetterButton.isEnabled = true
        }
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        
        guesslettermethod()
        guessmethod()
        let letter = guessLetterField.text
        if letter?.isEmpty == true{
            guessLetterButton.isEnabled = false
        }
        else{
            guessLetterButton.isEnabled = true
        }
    }
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        imageView.isHidden = true
        wordIterator += 1
        if wordIterator == arraywords.count {
            wordIterator = 0
            guessedwords = 0
            wronginputs = 0
            updateoutputs()
        }
        l = arraywords[wordIterator][0]
        guess = arraywords[wordIterator][1]
        hintLabel.text = "HINT: " + guess
        
        playAgainButton.isHidden = true
        guessLetterField.isEnabled = true
        guessLetterButton.isEnabled = false
        
        guessleft = maxNumOfWrongGuesses 
        guessedletcount = ""
        guesslabelouput()
        guessCountLabel.text = "You have Made 0 Guesses"
        count = 0
    }
            func updateImageView(){
                var count=0
                if(guessleft==0){
                     count = wordIterator
                    wordIterator=5
                }
                imageView.isHidden = false
                imageView.image = UIImage(named: imagesnames[wordIterator])
                let originalimages = imageView.frame
                let newwidth: CGFloat = 10
                let newheight: CGFloat = 10
                let rec = CGRect(
                x: imageView.frame.origin.x + newwidth,
                y: imageView.frame.origin.y + newheight,
                width: imageView.frame.width - newwidth,
                height: imageView.frame.height - newheight)
                imageView.frame = rec
                UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 10.0,  animations: {
                    self.imageView.frame = originalimages
                })
                if(guessleft==0){
                    wordIterator = count
                }
                
            
}

}
